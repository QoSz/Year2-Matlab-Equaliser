Some of the audio samples have been gotten from the lecture slides.

While some of the other audio sample can be found on this site:
https://www2.cs.uic.edu/~i101/SoundFiles/

Please Note:
Audio file Symphony No.6 (1st movement) may take a while to load as its a large audio file